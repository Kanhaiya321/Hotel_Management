package com.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateApplicationTests {

	@Test
	void contextLoads() {
	}

}
