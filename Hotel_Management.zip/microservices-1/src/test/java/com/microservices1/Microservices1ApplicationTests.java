package com.microservices1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Microservices1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
